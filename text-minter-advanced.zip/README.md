# Advanced Text Minter

A full-fledged DApp with:
- MetaMask wallet connection
- Pinata IPFS storage
- Solidity contract on Story blockchain (or compatible)

## Setup
1. Replace `YOUR_PINATA_API_KEY`, `YOUR_PINATA_SECRET_API_KEY` in `pinata.js`.
2. Deploy `TextMinter.sol` using Remix/Hardhat and update the address in `blockchain.js`.
3. Serve `index.html` using VS Code Live Server.
