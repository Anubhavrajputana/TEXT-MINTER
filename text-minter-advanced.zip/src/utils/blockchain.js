import abi from "../abi/TextMinterABI.json" assert { type: "json" };

const contractAddress = "YOUR_CONTRACT_ADDRESS";

export async function connectWallet() {
  if (!window.ethereum) {
    alert("Install MetaMask to use this DApp!");
    return;
  }
  const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
  return accounts[0];
}

export async function mintToBlockchain(textUri) {
  try {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const contract = new ethers.Contract(contractAddress, abi, signer);
    const tx = await contract.mintText(textUri);
    await tx.wait();
    return true;
  } catch (e) {
    console.error(e);
    return false;
  }
}
