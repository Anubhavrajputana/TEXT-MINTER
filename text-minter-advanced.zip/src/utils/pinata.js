export async function uploadToIPFS(content) {
  const pinataApiKey = "YOUR_PINATA_API_KEY";
  const pinataSecretApiKey = "YOUR_PINATA_SECRET_API_KEY";

  const response = await fetch("https://api.pinata.cloud/pinning/pinJSONToIPFS", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      pinata_api_key: pinataApiKey,
      pinata_secret_api_key: pinataSecretApiKey
    },
    body: JSON.stringify({ text: content })
  });

  const data = await response.json();
  return data.IpfsHash ? `https://gateway.pinata.cloud/ipfs/${data.IpfsHash}` : null;
}
