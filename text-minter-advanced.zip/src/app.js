import { uploadToIPFS } from "./utils/pinata.js";
import { connectWallet, mintToBlockchain } from "./utils/blockchain.js";

window.mintText = async function () {
  const text = document.getElementById("text").value;
  const status = document.getElementById("status");
  if (!text) {
    status.innerText = "⚠️ Please enter some text.";
    return;
  }
  status.innerText = "🔗 Uploading to IPFS...";
  const ipfsUrl = await uploadToIPFS(text);
  if (!ipfsUrl) {
    status.innerText = "❌ IPFS upload failed.";
    return;
  }
  status.innerText = "🪙 Minting to blockchain...";
  const success = await mintToBlockchain(ipfsUrl);
  status.innerText = success ? "✅ Minted successfully!" : "❌ Minting failed.";
};
